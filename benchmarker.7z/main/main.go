package main

import (
	"bufio"
	"bytes"
	"io"
	"os"

	"github.com/sirkon/message"
	"github.com/youtube/vitess/go/cgzip"
)

//go:generate ldetool generate --package main parsing

func main() {
	p := &parser{}
	var zreader io.Reader
	if len(os.Args) != 2 {
		zreader = os.Stdin
	} else {
		rawreader, err := os.Open(os.Args[1])
		if err != nil {
			message.Critical(err)
		}
		defer rawreader.Close()
		zreader, err = cgzip.NewReaderBuffer(rawreader, 512*1024)
		if err != nil {
			message.Critical(err)
		}
	}
	reader := bufio.NewReaderSize(zreader, 128*1024)
	scanner := bufio.NewScanner(reader)

	dest := bufio.NewWriter(os.Stdout)
	defer dest.Flush()
	buf := &bytes.Buffer{}
	for scanner.Scan() {
		if ok, err := p.Parse(scanner.Bytes()); ok {
			buf.Reset()
			buf.Write(p.Name)
			buf.WriteByte('|')
			buf.Write(p.Count)
			buf.WriteByte('\n')
			dest.Write(buf.Bytes())
		} else if err != nil {
			message.Error(err)
		}
	}
	if scanner.Err() != nil {
		message.Critical(scanner.Err())
	}
}
