package main

import (
	"bufio"
	"bytes"
	"os"
	"strconv"

	"github.com/sirkon/message"
)

func main() {
	if len(os.Args) != 2 {
		message.Criticalf("Got %d parameters, one and only one is required", len(os.Args)-1)
	}
	lines, err := strconv.ParseInt(os.Args[1], 10, 64)
	if err != nil || lines <= 0 {
		message.Criticalf("Parameter must be positive number, got %s instead", os.Args[1])
	}

	nsrc := NewRandSource(65536)
	namesrc := NewRandomChoice([]string{
		"Vasya",
		"Petya",
		"Kolya",
		"Zhenya",
		"Masha",
		"Sasha",
		"Yegor",
		"Vova",
		"Dima",
		"Kuzya",
		"Denis",
		"Misha",
		"Olya",
		"Vanya",
		"Edik",
		"Tolya",
		"Alya",
		"Galya",
		"Yulya",
		"Nastya",
		"Katya",
		"Shura",
		"Vika",
		"Oleg",
		"Igor",
		"Lesha",
		"Sema",
		"Grisha",
		"Zhora",
		"Pasha",
		"Maxim",
		"Lyuba",
		"Raya",
		"Marusya",
		"Dusya",
		"Klavia",
		"Julius Caesar",
		"Publius Cornelious Scipio Africanus",
		"Hannibal Barca",
		"Alexandr Nevskiy",
		"Alexandr Suvorov",
		"Napoleon Bonaparte",
		"Georgiy Zhukov",
		"Erich Von Manstein",
	})
	dest := bufio.NewWriter(os.Stdout)
	defer dest.Flush()
	buf := &bytes.Buffer{}
	for i := 0; i < int(lines); i++ {
		buf.Reset()
		buf.Write(namesrc.RandomChoice())
		buf.WriteByte('|')
		buf.Write(nsrc.RandomChoice())
		buf.WriteByte('|')
		buf.Write(nsrc.RandomChoice())
		buf.WriteByte('|')
		buf.Write(nsrc.RandomChoice())
		buf.WriteByte('|')
		buf.Write(nsrc.RandomChoice())
		buf.WriteByte('|')
		buf.Write(nsrc.RandomChoice())
		buf.WriteByte('\n')
		dest.Write(buf.Bytes())
	}
}
