package main

import (
	"fmt"
	"math/rand"
)

// RandSource is a source of pseudo-random numbers
type RandSource struct {
	state  uint32
	source [][]byte
}

// NewRandSource constructor
func NewRandSource(sampleRange int) *RandSource {
	res := &RandSource{
		state:  123123,
		source: make([][]byte, sampleRange),
	}
	for i := range res.source {
		res.source[i] = []byte(fmt.Sprintf("%d", rand.Uint32()%10000))
	}
	return res
}

// NewRandomChoice constructor creates a random choice from
// the predefined set
func NewRandomChoice(sampleSet []string) *RandSource {
	res := &RandSource{
		state:  3234789,
		source: make([][]byte, len(sampleSet)),
	}
	for i, item := range sampleSet {
		res.source[i] = []byte(item)
	}
	return res
}

func (rs *RandSource) xorshift() uint32 {
	x := rs.state
	x ^= x << 13
	x ^= x >> 17
	x ^= x << 5
	rs.state = x
	return x
}

// RandomChoice get random value from precalculated set
func (rs *RandSource) RandomChoice() []byte {
	index := rs.xorshift()
	return rs.source[int(index)%len(rs.source)]
}

// Random returns pseudo-random number
func (rs *RandSource) Random() int {
	return int(rs.xorshift())
}
